#include <stdio.h>
#include <stdlib.h>

void main()
{
int i;
 for(i = 0 ; i < 7 ; i++)
 {
   printf("\n count line : %d " , i );
 }
 printf("\n\n");
}